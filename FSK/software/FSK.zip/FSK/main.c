
#include <stdio.h>
#include <stdlib.h>

/**************************************************************************/
/* Firmware Includes */
/**************************************************************************/

#include "CMSIS/a2fxxxm3.h"
#include "drivers/mss_pdma/mss_pdma.h"
#include "drivers/mss_watchdog/mss_watchdog.h"
#include "drivers/mss_uart/mss_uart.h"
#include "drivers/mss_gpio/mss_gpio.h"
//#include "drivers/mss_ethernet_mac/mss_ethernet_mac.h"

/**************************************************************************/
/* Preprocessor Macros*/
/**************************************************************************/

#define fabric_address 0x40050000
uint32_t pdma_cnt;

/**************************************************************************/
/* Function Prototype*/
/**************************************************************************/

void init_system();
void read();

/**************************************************************************/
/*Main Program*/
/**************************************************************************/

int main()
{
	init_system();
	pdma_cnt = 0;
	uint32_t * fabric_data = (uint32_t *)(fabric_address);
	uint32_t data;
	uint16_t i;
	data = *fabric_data;
	while (1){
/*
		printf("\nCOUNTER: %u\r\n", pdma_cnt);
		for (i=0; i<15; i++){
			data = *fabric_data;
			printf("%02x\r\n", data);
		}
		pdma_cnt++;
		*/
//		data = *fabric_data;
//		printf("%02x\r\n", data);
		read();
	}
}


/**************************************************************************/
/* Function to initialization all necessary hardware components for this*/
/* demo*/
/**************************************************************************/

void init_system()
{
	/* Disable the Watch Dog Timer */
	MSS_WD_disable( );

	PDMA_init();
    PDMA_configure
    (
       PDMA_CHANNEL_0,
       PDMA_MEM_TO_MEM,
       PDMA_LOW_PRIORITY | PDMA_WORD_TRANSFER | PDMA_INC_DEST_FOUR_BYTES,
       PDMA_DEFAULT_WRITE_ADJ
    );
	/* Initialize and configure UART0. */
/*
	MSS_UART_init
    (
    	&g_mss_uart0,
    	MSS_UART_57600_BAUD,
    	MSS_UART_DATA_8_BITS | MSS_UART_NO_PARITY | MSS_UART_ONE_STOP_BIT
    );
   */
	MSS_GPIO_init();
	MSS_GPIO_config( MSS_GPIO_0, MSS_GPIO_OUTPUT_MODE );
	MSS_GPIO_config( MSS_GPIO_1, MSS_GPIO_OUTPUT_MODE );
	MSS_GPIO_config( MSS_GPIO_2, MSS_GPIO_OUTPUT_MODE );
	MSS_GPIO_config( MSS_GPIO_3, MSS_GPIO_OUTPUT_MODE );
//	MSS_GPIO_set_output( MSS_GPIO_0, 1 );				// DACEN
//	MSS_GPIO_set_output( MSS_GPIO_1, 0 );				// PD
//	MSS_GPIO_set_output( MSS_GPIO_2, 0 );				// CS
	MSS_GPIO_set_output( MSS_GPIO_3, 0 );
	// DFS 1 for 2's complement 0 for binary shift

	// ethernet
	/*
	uint32_t mac_cfg = 0;
	uint32_t link_status = 0;
	MSS_MAC_init(MSS_PHY_ADDRESS_AUTO_DETECT);
	// stolen from their webserver example, turns out configuring the ethernet card is really important, bad idea to S&F
	mac_cfg = MSS_MAC_get_configuration();
	mac_cfg &= ~(MSS_MAC_CFG_STORE_AND_FORWARD | MSS_MAC_CFG_PASS_BAD_FRAMES);
	mac_cfg |=
		    MSS_MAC_CFG_RECEIVE_ALL |
		    MSS_MAC_CFG_PROMISCUOUS_MODE |
		    MSS_MAC_CFG_FULL_DUPLEX_MODE |
		    MSS_MAC_CFG_TRANSMIT_THRESHOLD_MODE |
		    MSS_MAC_CFG_THRESHOLD_CONTROL_00;
	MSS_MAC_configure(mac_cfg);
	while (!(link_status & 0x1))	// wait for link to come up
		link_status = MSS_MAC_link_status();
	printf("Ethernet up, link status is %x\r\n", (unsigned int)link_status);
	*/
}

void read(){
	printf("\nCOUNTER: %d\r\n", pdma_cnt);
    volatile uint32_t status_pdma = 0;
    volatile uint32_t rdata[15];
    uint8_t i;

    PDMA_start
    (
       PDMA_CHANNEL_0,
       (uint32_t)fabric_address,
       (uint32_t)&rdata,
       16
    );

    do
    {
        status_pdma = PDMA_status (PDMA_CHANNEL_0);
    }while (status_pdma == 0);

    for (i=0; i<16; i=i+1)
    	printf("%02x\r\n", rdata[i]);

    pdma_cnt++;
}
