#ifndef fsk_HW_PLATFORM_H_
#define fsk_HW_PLATFORM_H_
/*****************************************************************************
*
*Created by Actel SmartDesign  Wed Mar 16 20:58:30 2011
*
*Memory map specification for peripherals in fsk
*/

/*-----------------------------------------------------------------------------
* top_0 subsystem memory map
* Master(s) for this subsystem: top_0 
*---------------------------------------------------------------------------*/
#define CORRELATOR_0                    0x40050000U


#endif /* fsk_HW_PLATFORM_H_*/
