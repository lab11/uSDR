#ifndef top_HW_PLATFORM_H_
#define top_HW_PLATFORM_H_
/*****************************************************************************
*
*Created by Actel SmartDesign  Tue Mar 08 10:49:47 2011
*
*Memory map specification for peripherals in top
*/

/*-----------------------------------------------------------------------------
* top_mss_0 subsystem memory map
* Master(s) for this subsystem: top_mss_0 
*---------------------------------------------------------------------------*/
#define P_DAC_0                         0x40060000U


#endif /* top_HW_PLATFORM_H_*/
