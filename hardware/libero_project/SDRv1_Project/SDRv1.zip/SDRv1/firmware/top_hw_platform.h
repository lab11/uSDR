#ifndef top_HW_PLATFORM_H_
#define top_HW_PLATFORM_H_
/*****************************************************************************
*
*Created by Actel SmartDesign  Tue Jul 03 17:58:47 2012
*
*Memory map specification for peripherals in top
*/

/*-----------------------------------------------------------------------------
* zigbee_0 subsystem memory map
* Master(s) for this subsystem: zigbee_0 
*---------------------------------------------------------------------------*/
#define CORRELATOR_0                    0x40050000U
#define IDX_CONTROL_0                   0x40060000U
#define RADIO_CTL_0                     0x40070000U
#define MAX2831_SPI_0                   0x40080000U


#endif /* top_HW_PLATFORM_H_*/
