[ALIST]
Alists=
[CONE]
Cones=
[DRCSettings]
DRCMode=Minimal
[FIND]
Finder=0 1 0 0 0 0 0 0 0 0 0 0 0
StringToFind=*
CellType=
PaneName=
[FRAME]
Tools=HYDRA_ioed                                                      
ActiveTool=HYDRA_ioed
PropertyList=WindowPlacement                                                                                          
WindowPlacement=0 1 -1 -1 -1 -1 47 43 1412 902
[HIGHLIGHT GROUPS]
CurrentGroup=0
NumGroups=15
[HighlightGroup0]
Name=HighlightGroup0
Color=166 0 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup1]
Name=HighlightGroup1
Color=0 255 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup2]
Name=HighlightGroup2
Color=0 255 255
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup3]
Name=HighlightGroup3
Color=212 208 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup4]
Name=HighlightGroup4
Color=0 0 255
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup5]
Name=HighlightGroup5
Color=255 255 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup6]
Name=HighlightGroup6
Color=0 0 128
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup7]
Name=HighlightGroup7
Color=0 128 128
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup8]
Name=HighlightGroup8
Color=0 128 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup9]
Name=HighlightGroup9
Color=128 0 128
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup10]
Name=HighlightGroup10
Color=128 0 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup11]
Name=HighlightGroup11
Color=128 128 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup12]
Name=HighlightGroup12
Color=128 128 128
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup13]
Name=HighlightGroup13
Color=212 192 192
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup14]
Name=HighlightGroup14
Color=0 0 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HIERARCHY VIEW]
DockState=0
PropertyList=WindowPlacement                                                                                          
WindowPlacement=0 1 -1 -1 -1 -1 1 -2 201 592
ActiveTab=0
[I/O ATTRIBUTE EDITOR]
NumWindow=1
[I/O ATTRIBUTE EDITOR1]
PropertyList=ActiveTab PinsViewAttributeVisibility PinsViewFirstVisibleCol PinsViewFirstVisibleRow PinsViewFrozenCol PinsViewFrozenRow PinsViewRowSortKey PortsViewAttributeVisibility PortsViewFirstVisibleCol PortsViewFirstVisibleRow PortsViewFrozenCol PortsViewFrozenRow PortsViewRowSortKey WindowPlacement                                                                                          
ActiveTab=0
PinsViewAttributeVisibility=1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1
PinsViewFirstVisibleCol=1
PinsViewFirstVisibleRow=699
PinsViewFrozenCol=0
PinsViewFrozenRow=0
PinsViewRowSortKey=1 1
PortsViewAttributeVisibility=1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1
PortsViewFirstVisibleCol=1
PortsViewFirstVisibleRow=113
PortsViewFrozenCol=0
PortsViewFrozenRow=0
PortsViewRowSortKey=1 4
WindowPlacement=0 1 -1 -1 -4 -26 -48 6 1153 560
[LOG VIEW]
DockState=0
PropertyList=WindowPlacement                                                                                          
WindowPlacement=0 1 -1 -1 -1 -1 342 5 1349 155
[SELECTION]
Macros=0
Nets=0
Regions=
Modules=-1 -1
Paths=
[WORLD VIEW]
DockState=0
PropertyList=WindowPlacement                                                                                          
WindowPlacement=0 1 -1 -1 -1 -1 1 5 336 155
[PACKAGE VIEW]
MIRROR=0
Regular$Pins=1 65280 0
Special$Pins=1 16711680 0
Reserved$Pins=1 255 0
Unconnected$Pins=1 12632256 0
Vref=1 255 0
Locked$Module=1 65535 0
Selection=1 16777215 0
Bank0=1 8421631 0
Bank1=1 8323199 0
Bank2=1 7012567 0
Bank3=1 9568200 0
Bank4=1 16760960 0
Bank5=1 8454143 0
Bank6=1 33023 0
Bank7=1 128 0
Outline=1 12632256 0
Background=1 0 0
Text$On$Objects=1 0 0
Text$On$Background=1 12632256 0
PAN2SELECTED_MACRO=0
NumWindow=1
[PACKAGE VIEW1]
PropertyList=ViewportExtents WindowPlacement 
ViewportExtents=-171 -171 5166 1467
WindowPlacement=0 1 -1 -1 -1 -1 22 29 1237 448
