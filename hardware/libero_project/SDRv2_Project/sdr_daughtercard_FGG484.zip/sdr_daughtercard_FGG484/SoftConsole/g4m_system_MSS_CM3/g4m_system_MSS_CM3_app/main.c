/*******************************************************************************
 * (c) Copyright 2012 Actel Corporation. All rights reserved.
 * (c) Copyright 2012 Emcraft Systems.  All rights reserved.
 *
 *  Simple SmartFusion2 microcontroller subsystem (MSS)
 *  GPIO and UART example program.This sample program is targeted at
 *  the Emcraft Systems SmartFusion2 SOM Starter Kit.
 *  It blinks the board's LEDs and prints messages onto UART using a delay loop.
 *
 *  IMPORTANT NOTE:
 *          If you re-generate this SoftConsole project in context of the Libero
 *          project the SoftConsole project is included with, Libero will
 *          set the following line:
 *
 *  #define MSS_SYS_MDDR_CONFIG_BY_CORTEX 1
 *          in
 *  g4m_system_MSS_CM3_hw_platform/drivers_config/sys_config/sys_config.h.
 *
 *          This is because the DDR interface is enabled in the Libero project.
 *          However, the DDR initialization code included with the current rev
 *          of Libero is not compatible with Emcraft Systems's SOM design.
 *          When called, the DDR initialization code will
 *          loop in config_ddr_subsys().
 *          Disable MSS_SYS_MDDR_CONFIG_BY_CORTEX to let this
 *          SoftConsole project run.
 *
 *  NOTE:   This sample project expects that the MSS GPIOs are connected to
 *          external pins through the FPGA fabric as follows:
 *              - MSS_GPIO_1: input from pin B20
 *              - MSS_GPIO_2: input from pin C19
 *          MSS UART0 is used as the serial console.
 *
 */

#include "drivers/mss_gpio/mss_gpio.h"
#include "drivers/mss_uart/mss_uart.h"
#include "drivers_config/sys_config/sys_config.h"
#include <stdio.h>

#if (MSS_SYS_MDDR_CONFIG_BY_CORTEX == 1)
#error "Please turn off DDR initialization! See the comment in this file above."
#endif

/*
 * Delay loop down counter load value.
 */
#define DELAY_LOAD_VALUE     0x00800000


/*
 * LEDs GPIOs
 */
#define DS3_LED_GPIO	MSS_GPIO_1
#define DS4_LED_GPIO	MSS_GPIO_2
#define DS3_LED_MASK	MSS_GPIO_1_MASK
#define DS4_LED_MASK	MSS_GPIO_2_MASK


#define RAM_BASE_ADDR	0xA0000000

uint32_t MDDR_status=0;

void config_mddr_lpddr(void)
{
    MDDR->core.ddrc.DYN_SOFT_RESET_CR 		        = 0x0000;
    MDDR->core.ddrc.DYN_REFRESH_1_CR 				= 0x27de;
    MDDR->core.ddrc.DYN_REFRESH_2_CR 		        = 0x030f;
    MDDR->core.ddrc.DYN_POWERDOWN_CR 		        = 0x0002;
    MDDR->core.ddrc.DYN_DEBUG_CR 		        	= 0x0000;
    MDDR->core.ddrc.MODE_CR 			        	= 0x00C1;
    MDDR->core.ddrc.ADDR_MAP_BANK_CR 		        = 0x099f;
    MDDR->core.ddrc.ECC_DATA_MASK_CR 		        = 0x0000;
    MDDR->core.ddrc.ADDR_MAP_COL_1_CR 		        = 0x3333;
    MDDR->core.ddrc.ADDR_MAP_COL_2_CR 		        = 0xffff;
    MDDR->core.ddrc.ADDR_MAP_ROW_1_CR 		        = 0x7777;
    MDDR->core.ddrc.ADDR_MAP_ROW_2_CR 		        = 0x0fff;
    MDDR->core.ddrc.INIT_1_CR 			        	= 0x0001;
    MDDR->core.ddrc.CKE_RSTN_CYCLES_CR[0] 	       	= 0x4242;
    MDDR->core.ddrc.CKE_RSTN_CYCLES_CR[1] 	       	= 0x0008;
    MDDR->core.ddrc.INIT_MR_CR 			        	= 0x0033;
    MDDR->core.ddrc.INIT_EMR_CR 		        	= 0x0020;
    MDDR->core.ddrc.INIT_EMR2_CR 		        	= 0x0000;
    MDDR->core.ddrc.INIT_EMR3_CR 		        	= 0x0000;
    MDDR->core.ddrc.DRAM_BANK_TIMING_PARAM_CR		= 0x00c0;
    MDDR->core.ddrc.DRAM_RD_WR_LATENCY_CR 	       	= 0x0023;
    MDDR->core.ddrc.DRAM_RD_WR_PRE_CR 		        = 0x0235;
    MDDR->core.ddrc.DRAM_MR_TIMING_PARAM_CR			= 0x0064;
    MDDR->core.ddrc.DRAM_RAS_TIMING_CR 		        = 0x0108;
    MDDR->core.ddrc.DRAM_RD_WR_TRNARND_TIME_CR		= 0x0178;
    MDDR->core.ddrc.DRAM_T_PD_CR 		        	= 0x0033;
    MDDR->core.ddrc.DRAM_BANK_ACT_TIMING_CR			= 0x1947;
    MDDR->core.ddrc.ODT_PARAM_1_CR					= 0x0010;
    MDDR->core.ddrc.ODT_PARAM_2_CR					= 0x0000;
    MDDR->core.ddrc.ADDR_MAP_COL_3_CR 		        = 0x3300;
    MDDR->core.ddrc.MODE_REG_RD_WR_CR 		        = 0x0000;
    MDDR->core.ddrc.MODE_REG_DATA_CR 		        = 0x0000;
    MDDR->core.ddrc.PWR_SAVE_1_CR 		       		= 0x0514;
    MDDR->core.ddrc.PWR_SAVE_2_CR 		       		= 0x0000;
    MDDR->core.ddrc.ZQ_LONG_TIME_CR 		        = 0x0200;
    MDDR->core.ddrc.ZQ_SHORT_TIME_CR 		        = 0x0040;
    MDDR->core.ddrc.ZQ_SHORT_INT_REFRESH_MARGIN_CR[0] 	= 0x0012;
    MDDR->core.ddrc.ZQ_SHORT_INT_REFRESH_MARGIN_CR[1] 	= 0x0002;
    MDDR->core.ddrc.PERF_PARAM_1_CR 			= 0x4000;
    MDDR->core.ddrc.HPR_QUEUE_PARAM_CR[0]	 	= 0x80f8;
    MDDR->core.ddrc.HPR_QUEUE_PARAM_CR[1] 	 	= 0x0007;
    MDDR->core.ddrc.LPR_QUEUE_PARAM_CR[0] 	 	= 0x80f8;
    MDDR->core.ddrc.LPR_QUEUE_PARAM_CR[1] 	 	= 0x0007;
    MDDR->core.ddrc.WR_QUEUE_PARAM_CR 	 		= 0x0200;
    MDDR->core.ddrc.PERF_PARAM_2_CR 	 		= 0x0001;
    MDDR->core.ddrc.PERF_PARAM_3_CR 	 		= 0x0000;
    MDDR->core.ddrc.DFI_RDDATA_EN_CR 	 		= 0x0003;
    MDDR->core.ddrc.DFI_MIN_CTRLUPD_TIMING_CR 	= 0x0003;
    MDDR->core.ddrc.DFI_MAX_CTRLUPD_TIMING_CR 	= 0x0040;
    MDDR->core.ddrc.DFI_WR_LVL_CONTROL_CR[0] 	= 0x0000;
    MDDR->core.ddrc.DFI_WR_LVL_CONTROL_CR[1] 	= 0x0000;
    MDDR->core.ddrc.DFI_RD_LVL_CONTROL_CR[0] 	= 0x0000;
    MDDR->core.ddrc.DFI_RD_LVL_CONTROL_CR[1] 	= 0x0000;
    MDDR->core.ddrc.DFI_CTRLUPD_TIME_INTERVAL_CR	= 0x0309;
    MDDR->core.ddrc.AXI_FABRIC_PRI_ID_CR 		= 0x0000;
    MDDR->core.ddrc.ECC_INT_CLR_REG 			= 0x0000;

    MDDR->core.phy.LOOPBACK_TEST_CR 			= 0x0000;
    MDDR->core.phy.CTRL_SLAVE_RATIO_CR 			= 0x0080;
    MDDR->core.phy.DATA_SLICE_IN_USE_CR 		= 0x0003;
    MDDR->core.phy.DQ_OFFSET_CR[0] 				= 0x00000000;
    MDDR->core.phy.DQ_OFFSET_CR[2] 				= 0x0000;
    MDDR->core.phy.DLL_LOCK_DIFF_CR  			= 0x000B;
    MDDR->core.phy.FIFO_WE_SLAVE_RATIO_CR[0] 	= 0x0040;
    MDDR->core.phy.FIFO_WE_SLAVE_RATIO_CR[1] 	= 0x0401;
    MDDR->core.phy.FIFO_WE_SLAVE_RATIO_CR[2] 	= 0x4010;
    MDDR->core.phy.FIFO_WE_SLAVE_RATIO_CR[3] 	= 0x0000;
    MDDR->core.phy.LOCAL_ODT_CR  				= 0x0001;
    MDDR->core.phy.RD_DQS_SLAVE_RATIO_CR[0]  	= 0x0040;
    MDDR->core.phy.RD_DQS_SLAVE_RATIO_CR[1]  	= 0x0401;
    MDDR->core.phy.RD_DQS_SLAVE_RATIO_CR[2]  	= 0x4010;
    MDDR->core.phy.WR_DATA_SLAVE_RATIO_CR[0]  	= 0x0040;
    MDDR->core.phy.WR_DATA_SLAVE_RATIO_CR[1]  	= 0x0401;
    MDDR->core.phy.WR_DATA_SLAVE_RATIO_CR[2]  	= 0x4010;
    MDDR->core.phy.WR_RD_RL_CR  				= 0x0021;
    MDDR->core.phy.RDC_WE_TO_RE_DELAY_CR  		= 0x0003;
    MDDR->core.phy.USE_FIXED_RE_CR  			= 0x0001;
    MDDR->core.phy.USE_RANK0_DELAYS_CR  		= 0x0001;
    MDDR->core.phy.CONFIG_CR  			 		= 0x0009;
    MDDR->core.phy.DYN_RESET_CR  				= 0x01;
    MDDR->core.ddrc.DYN_SOFT_RESET_CR  			= 0x01;

    while((MDDR->core.ddrc.DDRC_SR) == 0x0000)
    {
        ;
    }
}


/*
 * main() function.
 */
int main()
{
    int32_t delay_count = 0;
    char *memptr = (char *)RAM_BASE_ADDR;

    /*
     * Initialize MSS GPIOs.
     */
    MSS_GPIO_init();

    /*
     * Configure MSS GPIOs.
     */
    MSS_GPIO_config(DS3_LED_GPIO, MSS_GPIO_OUTPUT_MODE);
    MSS_GPIO_config(DS4_LED_GPIO, MSS_GPIO_OUTPUT_MODE);

    /*
     * Set LEDs to initial state
     */
    MSS_GPIO_set_outputs(MSS_GPIO_get_outputs() | DS3_LED_MASK | DS4_LED_MASK);

    /*
     * Set initial delay used to blink the LED.
     */
    delay_count = DELAY_LOAD_VALUE;

    /*
     * Initialize the UART0 controller (115200, 8N1)
     */
    MSS_UART_init(&g_mss_uart0, MSS_UART_115200_BAUD, MSS_UART_DATA_8_BITS |
	    MSS_UART_NO_PARITY | MSS_UART_ONE_STOP_BIT);

    config_mddr_lpddr();

    sprintf(memptr, "%s\n\r", "Hello, SmartFusion2!");

    /*
     * Infinite loop.
     */
    for(;;)
    {
	    uint32_t val;

	    /*
	     * Decrement delay counter.
	     */
	    --delay_count;

	    /*
	     * Check if delay expired.
	     */
	    if ( delay_count <= 0 )
	    {
		    /*
		     * Reload delay counter.
		     */
		    delay_count = DELAY_LOAD_VALUE;

		    /*
		     * Toggle GPIO output pattern by doing an exclusive OR of
		     * all pattern bits with ones.
		     */
		    val = MSS_GPIO_get_outputs() & (DS3_LED_MASK | DS4_LED_MASK);
		    val ^= (DS3_LED_MASK | DS4_LED_MASK);
		    MSS_GPIO_set_outputs( val );

		    /*
		     * Print the message to the UART console
		     */
		    MSS_UART_polled_tx_string(&g_mss_uart0,
				 (const uint8_t *)memptr);
	    }
    }

    return 0;
}
