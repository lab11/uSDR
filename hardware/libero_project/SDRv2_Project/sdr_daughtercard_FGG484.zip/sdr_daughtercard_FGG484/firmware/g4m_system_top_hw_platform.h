#ifndef g4m_system_top_HW_PLATFORM_H_
#define g4m_system_top_HW_PLATFORM_H_
/*****************************************************************************
*
*Created by Actel SmartDesign  Fri Dec 13 19:22:47 2013
*
*Memory map specification for peripherals in g4m_system_top
*/

/*-----------------------------------------------------------------------------
* CM3 subsystem memory map
* Master(s) for this subsystem: CM3 FABRIC2MSSFIC2 
*---------------------------------------------------------------------------*/
#define G4M_SYSTEM_MSS_0                0x40020800U
#define SDRV2_TOP_0_APB0                0x30000000U
#define SDRV2_TOP_0_APB1                0x30010000U
#define SDRV2_TOP_0_APB2                0x30020000U
#define SDRV2_TOP_0_APB3                0x30030000U
#define LED_WRAPPER_0                   0x30040000U


#endif /* g4m_system_top_HW_PLATFORM_H_*/
