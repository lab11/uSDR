#ifndef Top_HW_PLATFORM_H_
#define Top_HW_PLATFORM_H_
/*****************************************************************************
*
*Created by Actel SmartDesign  Wed Sep 19 10:58:27 2012
*
*Memory map specification for peripherals in Top
*/

/*-----------------------------------------------------------------------------
* SDR_MSS_0 subsystem memory map
* Master(s) for this subsystem: SDR_MSS_0 
*---------------------------------------------------------------------------*/
#define SDRV2_TOP_0                     0x40050000U
#define SDRV2_TOP_0                     0x40060000U
#define SDRV2_TOP_0                     0x40070000U
#define SDRV2_TOP_0                     0x40080000U


#endif /* Top_HW_PLATFORM_H_*/
