#ifndef TOPLEVEL_HW_PLATFORM_H_
#define TOPLEVEL_HW_PLATFORM_H_
/*****************************************************************************
*
*Created by Actel SmartDesign  Fri Sep 14 11:07:48 2012
*
*Memory map specification for peripherals in TOPLEVEL
*/

/*-----------------------------------------------------------------------------
* MSS_CORE2_0 subsystem memory map
* Master(s) for this subsystem: MSS_CORE2_0 
*---------------------------------------------------------------------------*/
#define PSRAM_CR_0                      0x40050000U


#endif /* TOPLEVEL_HW_PLATFORM_H_*/
