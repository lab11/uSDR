
#ifndef AMAC_H_
#define AMAC_H_

#endif
